package geekbrains.lesson_01.actions;

public interface Run {
  boolean running(int distance);
}
