package geekbrains.lesson_01.actions;

public interface Jump {
    boolean jumping (int height);
//        System.out.println ("Test" );
}
