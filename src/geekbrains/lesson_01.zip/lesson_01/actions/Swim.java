package geekbrains.lesson_01.actions;

public interface Swim {
    boolean swimming(int distance);
}
