package geekbrains.lesson_01.obstacles;

import geekbrains.lesson_01.participants.Participant;

public interface Obstacles  {
    int obstacleInfo();
    void doIt(Participant participant, int i);
}
