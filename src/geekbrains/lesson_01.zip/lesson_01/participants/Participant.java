package geekbrains.lesson_01.participants;

import geekbrains.lesson_01.actions.Jump;
import geekbrains.lesson_01.actions.Run;
import geekbrains.lesson_01.actions.Swim;

public interface Participant extends Run , Jump , Swim {
}
